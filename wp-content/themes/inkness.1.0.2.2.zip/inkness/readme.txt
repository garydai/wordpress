Thank you for Using Inkness Wordpress Theme. For Support read the Documentation-Inkness.pdf file which is available with this theme. For any other help please visit http://inkhive.com

	i) Inkness WordPress Theme is Based on the Underscores Framework http://underscores.me/, (C) 2012-2013 Automattic, Inc. 
	ii) Inkness has been created Rohit Tripathi. You can Follow me on http://github.com/rohitink.
	iv) It comes GNU General Public License. More Details about the License can be found in the license.txt file included in the theme.
	
## Copyrights for Resources used in this theme.
	i) Inkness Uses Elements from the Bootstrap Framework, which is under the Apache v2 license.
	ii) Font-Awesome Icons are under the MIT Licnese.
	iii) This theme uses nivoSlider, which is under the MIT License. More details: 
	        http://nivo.dev7studios.com
	   		http://www.opensource.org/licenses/mit-license.php
	iv) For the Administration Panel, we have used "Options Framework", which is under GPL v2 license. http://wptheming.com/options-framework-theme/
	v) The files options-custom.js, color-picker.js and media-uploader.js present in the "/js" Folder are part of the "Options Framework", and are under GPL v2.
	vi) custom.js has been created by me and under GPL v2.
	vii) skip-link-focus-fix.js, navigation.js, customizer.js & keyboard-image-navigation.js are part of the Underscores Framework used by the theme, and hence under GPL v2.
	viii) The images nthumb have been created by me for the purpose of this theme. 2cl and 2cr are part of Options framework and are under GPL license.
	ix) The files in the css/ folder are a part of nivoSlider and under MIT license.
	x) The Timeago Plugin used in this theme is under the MIT License. http://timeago.yarp.com/
	
Everything else used in this theme has been created by me, especially for Inkness theme and is distributed under GPL license.
	
For any help you can mail me at rohit[at]rohitink.com