jQuery(document).ready(function(){
	// Style form controls
	jQuery( type="select" ).addClass( 'form-control input-sm' );
	jQuery( 'input#submit' ).addClass( 'btn btn-default' );
	// Tables
	jQuery( 'table' ).addClass( 'table' );
});
